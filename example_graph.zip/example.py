from graph import *

start()
Funtions.f()
exitonclick()